#ifndef USER_USB_RAM
#error "USB Settings must be USER CODE w/148B USB RAM"
#endif

#include "src/userUsbHidKeyboard/USBHIDKeyboard.h"


/* ============================================================
 *                  ↓↓↓ 可自行修改区域 ↓↓↓
 * ============================================================ */

// 设备插入电脑后，等待多久再开始输入。
// Mac 第一次连接可能弹“键盘设置助理”，建议先用 10000~15000ms。
#define START_DELAY_MS  10000

// 每个字符之间的间隔。
// 20~50ms 比较稳；太快可能导致某些电脑漏字符。
#define KEY_DELAY_MS    40

// 输入完成后是否按一次回车：
// 1 = 按回车
// 0 = 不按回车
#define SEND_ENTER      1

// 是否重复发送：
// 0 = 每次插入 USB 只执行一次（推荐）
// 1 = 周期性重复输入
#define REPEAT_ENABLE   0

// 如果开启重复发送，两次发送之间等待多久。
#define REPEAT_DELAY_MS 10000


// ------------------------------------------------------------
// ★ 最常修改的地方：要自动输入的文字
//
// 建议先只使用标准 ASCII：
// A-Z a-z 0-9 以及常见英文符号。
// 测试阶段不要直接放中文。
// ------------------------------------------------------------
const char TEST_TEXT[] = "CH552 MAC HID OK";

// 所有特殊键：
/*
KEY_RETURN
KEY_ESC
KEY_TAB
KEY_BACKSPACE
KEY_DELETE

KEY_UP_ARROW
KEY_DOWN_ARROW
KEY_LEFT_ARROW
KEY_RIGHT_ARROW

KEY_HOME
KEY_END
KEY_PAGE_UP
KEY_PAGE_DOWN

KEY_LEFT_CTRL
KEY_LEFT_SHIFT
KEY_LEFT_ALT
KEY_LEFT_GUI      // Mac 上就是 Command

KEY_RIGHT_CTRL
KEY_RIGHT_SHIFT
KEY_RIGHT_ALT
KEY_RIGHT_GUI

KEY_F1
...
KEY_F24
*/

// 组合键用法：
/*
Keyboard_press(KEY_LEFT_SHIFT);
Keyboard_press('a');

delay(100);

Keyboard_releaseAll();
*/
// 实际是同时按下 Shift + A

/* ============================================================
 *                  ↑↑↑ 可自行修改区域 ↑↑↑
 * ============================================================ */


bool sent = false;


// 逐字符输入字符串
void typeText(const char *text) {
  uint16_t i = 0;

  while (text[i] != '\0') {
    Keyboard_write(text[i]);
    delay(KEY_DELAY_MS);
    i++;
  }
}


// 按一下指定按键
void tapKey(uint8_t key) {
  Keyboard_press(key);
  delay(100);
  Keyboard_release(key);
}


// 实际执行的 HID 动作
void runPayload() {

  // 防止之前有按键处于按下状态
  Keyboard_releaseAll();
  delay(100);

  // 输入自定义文字
  typeText(TEST_TEXT);

#if SEND_ENTER
  delay(100);
  tapKey(KEY_RETURN);
#endif

  // 最后确保全部释放
  Keyboard_releaseAll();
}


void setup() {

  // 初始化 USB HID
  USBInit();

  // 等电脑完成 USB/HID 枚举
  delay(START_DELAY_MS);
}


void loop() {

#if REPEAT_ENABLE

  runPayload();
  delay(REPEAT_DELAY_MS);

#else

  // 默认每次上电只执行一次
  if (!sent) {
    sent = true;
    runPayload();
  }

  delay(100);

#endif
}