#ifndef USER_USB_RAM
#error "USB Settings must be USER CODE w/148B USB RAM"
#endif

#include "src/userUsbHidKeyboard/USBHIDKeyboard.h"


/* ============================================================
 *                  可自行修改区域
 * ============================================================ */

// 插入 Windows 后等待多久开始执行。
// 第一次连接 HID 设备时 Windows 可能需要一点时间加载驱动。
// 建议 8000~12000 ms。
#define START_DELAY_MS 10000

// Win + R 后等待“运行”窗口弹出的时间。
#define RUN_DIALOG_DELAY_MS 1200

// 每个字符的输入间隔。
// 如果出现漏字符，可以改成 60~100。
#define KEY_DELAY_MS 40

// ★ 要打开的网址，主要修改这里
const char URL[] =
  "https://github.com/Seanasia/VeryBadUSB/blob/main/index.md";


/* ============================================================
 *              通常不需要修改下面的代码
 * ============================================================ */

bool executed = false;


// ------------------------------------------------------------
// 输入普通 ASCII 文本
// ------------------------------------------------------------
void typeText(const char *text) {
  uint16_t i = 0;

  while (text[i] != '\0') {
    Keyboard_write(text[i]);
    delay(KEY_DELAY_MS);
    i++;
  }
}


// ------------------------------------------------------------
// 按一下指定按键
// ------------------------------------------------------------
void tapKey(uint8_t key) {
  Keyboard_press(key);
  delay(100);
  Keyboard_release(key);
}


// ------------------------------------------------------------
// Windows：Win + R
// ------------------------------------------------------------
void openRunDialog() {
  Keyboard_releaseAll();
  delay(100);

  // Windows 键在 USB HID 中对应 GUI 键
  Keyboard_press(KEY_LEFT_GUI);
  Keyboard_press('r');

  delay(150);

  Keyboard_releaseAll();

  // 等待“运行”窗口出现
  delay(RUN_DIALOG_DELAY_MS);
}


// ------------------------------------------------------------
// 实际执行内容
// ------------------------------------------------------------
void runPayload() {
  Keyboard_releaseAll();
  delay(200);

  // 1. Win + R
  openRunDialog();

  // 2. 输入网址
  typeText(URL);

  delay(200);

  // 3. Enter
  tapKey(KEY_RETURN);

  // 确保所有按键释放
  Keyboard_releaseAll();
}


// ------------------------------------------------------------
// 初始化
// ------------------------------------------------------------
void setup() {
  USBInit();

  // 等待 Windows 完成 USB HID 枚举
  delay(START_DELAY_MS);
}


// ------------------------------------------------------------
// 主循环
// ------------------------------------------------------------
void loop() {

  // 每次上电只执行一次
  if (!executed) {
    executed = true;

    runPayload();
  }

  delay(100);
}